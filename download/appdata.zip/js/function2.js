function function2() {
    console.log('function2');
    document.getElementById('function2').innerHTML = 'OK';
}