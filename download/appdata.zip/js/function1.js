function function1() {
  console.log('function1');
  document.getElementById('function1').innerHTML = 'OK';
}